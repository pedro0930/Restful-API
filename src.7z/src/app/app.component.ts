import { Component } from '@angular/core';
import { HttpService } from './http.service';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent {
  title = 'app';
  constructor(private _httpService: HttpService){

  }
  ngOnInit(){
    this.getPokemonFromService()
  }
  pokemon = [];
  abilities = [];
  displayString = "";
  getPokemonFromService(){
    let observable = this._httpService.getPokemon()
    observable.subscribe(data =>{
      console.log("Here be data", data)
      this.pokemon = data['pokemon']
      this.displayString += "My Favorite Pokemon is " + data.name +". " +"It's special abilities are " + data.abilities[0].ability.name + " and " + data.abilities[1].ability.name+ ". It is of type "+ data.types[0].type.name + " and " + data.types[1].type.name +"."
      console.log(this.displayString)
      console.log("Other pokemon with similar abilities are...: \n")
      observable = this._httpService.getSameAbility()
      observable.subscribe(data =>{
        this.abilities = data["ability"]
        // console.log("Here be ability data", data)
        for(var i = 0; i < data.pokemon.length; i++){
          console.log(data.pokemon[i].pokemon.name)
        }
      })
    })
  }
}