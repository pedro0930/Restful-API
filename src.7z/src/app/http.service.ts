import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { timeout } from 'q';
import { TIMEOUT } from 'dns';



@Injectable({
  providedIn: 'root'
})



export class HttpService {
    constructor(private _http: HttpClient){

    }
    getPokemon(){
        let pokemon = this._http.get('https://pokeapi.co/api/v2/pokemon/3/');
        // pokemon.subscribe(data => console.log("My Favorite Pokemon is", data.name))
        // pokemon.subscribe(data => console.log("It's special abilities are", data.abilities[0].ability.name, "and", data.abilities[1].ability.name))
        // pokemon.subscribe(data => console.log("It is of type", data.types[0].type.name], "and", data.types[1].type.name]))
        return pokemon
    }
    getSameAbility(){
        let ability = this._http.get("https://pokeapi.co/api/v2/ability/3/")
        return ability
    }
    
}

